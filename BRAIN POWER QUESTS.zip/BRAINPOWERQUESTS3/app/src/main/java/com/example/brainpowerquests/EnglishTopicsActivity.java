package com.example.brainpowerquests;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class EnglishTopicsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english_topics);

        setupButton(R.id.spellingBtn, "Spelling master");
        setupButton(R.id.grammarBtn, "Grammar hunter");
        setupButton(R.id.punctuationBtn, "Punctuation Fixer");
        setupButton(R.id.arrangeBtn, "Arrange The Word");

        Button backBtn = findViewById(R.id.backBtn);
        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                finish(); // Returns to Subject Selection
            });
        }
    }

    private void setupButton(int id, String topicName) {
        Button btn = findViewById(id);
        if (btn != null) {
            btn.setOnClickListener(v -> {
                Intent intent = new Intent(EnglishTopicsActivity.this, QuizActivity.class);
                intent.putExtra("topic", topicName);
                startActivity(intent);
            });
        }
    }
}
