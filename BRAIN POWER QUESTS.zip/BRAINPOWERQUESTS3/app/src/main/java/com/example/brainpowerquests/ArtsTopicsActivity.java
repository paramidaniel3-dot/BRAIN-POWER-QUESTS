package com.example.brainpowerquests;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class ArtsTopicsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arts_topics);

        setupButton(R.id.visualArtsBtn, "Visual Arts");
        setupButton(R.id.performingArtsBtn, "Performing Arts");
        setupButton(R.id.musicBtn, "Music");
        setupButton(R.id.architectureBtn, "Architecture");
        setupButton(R.id.culturalArtsBtn, "Cultural & Contemporary Arts");

        Button backBtn = findViewById(R.id.backBtn);
        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                finish(); // Returns to Subject Selection
            });
        }
    }

    private void setupButton(int id, String topicName) {
        Button btn = findViewById(id);
        if (btn != null) {
            btn.setOnClickListener(v -> {
                Intent intent = new Intent(ArtsTopicsActivity.this, QuizActivity.class);
                intent.putExtra("topic", topicName);
                startActivity(intent);
            });
        }
    }
}
