package com.example.brainpowerquests;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MathTopicsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_math_topics);

        setupButton(R.id.arithmeticBtn, "Arithmetic");
        setupButton(R.id.algebraBtn, "Algebra 1 & 2");
        setupButton(R.id.geometryBtn, "Geometry");
        setupButton(R.id.trigonometryBtn, "Trigonometry");

        Button backBtn = findViewById(R.id.backBtn);
        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                finish(); // Returns to Subject Selection
            });
        }
    }

    private void setupButton(int id, String topicName) {
        Button btn = findViewById(id);
        if (btn != null) {
            btn.setOnClickListener(v -> {
                Intent intent = new Intent(MathTopicsActivity.this, QuizActivity.class);
                intent.putExtra("topic", topicName);
                startActivity(intent);
            });
        }
    }
}
