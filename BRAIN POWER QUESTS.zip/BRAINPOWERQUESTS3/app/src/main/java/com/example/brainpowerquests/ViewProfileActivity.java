package com.example.brainpowerquests;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ViewProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        TextView viewName = findViewById(R.id.viewName);
        TextView viewAge = findViewById(R.id.viewAge);
        TextView viewGender = findViewById(R.id.viewGender);
        TextView viewAddress = findViewById(R.id.viewAddress);
        TextView viewSchool = findViewById(R.id.viewSchool);
        TextView viewYearLevel = findViewById(R.id.viewYearLevel);
        Button backToMenuBtn = findViewById(R.id.backToMenuBtn);

        // Load data from SharedPreferences
        SharedPreferences sharedPref = getSharedPreferences("UserProfile", Context.MODE_PRIVATE);
        
        viewName.setText("Name: " + sharedPref.getString("name", "N/A"));
        viewAge.setText("Age: " + sharedPref.getString("age", "N/A"));
        viewGender.setText("Gender: " + sharedPref.getString("gender", "N/A"));
        viewAddress.setText("Home Address: " + sharedPref.getString("address", "N/A"));
        viewSchool.setText("School: " + sharedPref.getString("school", "N/A"));
        viewYearLevel.setText("Year Level: " + sharedPref.getString("yearLevel", "N/A"));

        if (backToMenuBtn != null) {
            backToMenuBtn.setOnClickListener(v -> finish());
        }
    }
}
