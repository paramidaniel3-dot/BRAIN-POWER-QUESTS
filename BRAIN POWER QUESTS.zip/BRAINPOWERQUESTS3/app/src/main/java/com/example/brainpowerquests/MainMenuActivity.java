package com.example.brainpowerquests;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Button selectSubjectBtn = findViewById(R.id.selectSubjectBtn);
        Button exitBtn = findViewById(R.id.exitBtn);
        Button backBtn = findViewById(R.id.backBtn);
        Button profileBtn = findViewById(R.id.profileBtn);

        if (selectSubjectBtn != null) {
            selectSubjectBtn.setOnClickListener(v -> {
                Intent intent = new Intent(MainMenuActivity.this, SubjectSelectionActivity.class);
                startActivity(intent);
            });
        }

        if (profileBtn != null) {
            profileBtn.setOnClickListener(v -> {
                Intent intent = new Intent(MainMenuActivity.this, ViewProfileActivity.class);
                startActivity(intent);
            });
        }

        if (exitBtn != null) {
            exitBtn.setOnClickListener(v -> {
                finishAffinity();
            });
        }

        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                finish(); // Returns to the Welcome screen
            });
        }
    }
}
