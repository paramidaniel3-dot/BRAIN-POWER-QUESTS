package com.example.brainpowerquests;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class SubjectSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject_selection);

        Button mathBtn = findViewById(R.id.mathBtn);
        if (mathBtn != null) {
            mathBtn.setOnClickListener(v -> {
                Intent intent = new Intent(this, MathTopicsActivity.class);
                startActivity(intent);
            });
        }

        Button englishBtn = findViewById(R.id.englishBtn);
        if (englishBtn != null) {
            englishBtn.setOnClickListener(v -> {
                Intent intent = new Intent(this, EnglishTopicsActivity.class);
                startActivity(intent);
            });
        }

        Button scienceBtn = findViewById(R.id.scienceBtn);
        if (scienceBtn != null) {
            scienceBtn.setOnClickListener(v -> {
                Intent intent = new Intent(this, ScienceTopicsActivity.class);
                startActivity(intent);
            });
        }

        Button historyBtn = findViewById(R.id.historyBtn);
        if (historyBtn != null) {
            historyBtn.setOnClickListener(v -> {
                Intent intent = new Intent(this, HistoryTopicsActivity.class);
                startActivity(intent);
            });
        }

        Button artsBtn = findViewById(R.id.artsBtn);
        if (artsBtn != null) {
            artsBtn.setOnClickListener(v -> {
                Intent intent = new Intent(this, ArtsTopicsActivity.class);
                startActivity(intent);
            });
        }

        Button backBtn = findViewById(R.id.backBtn);
        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                finish(); // Returns to Main Menu
            });
        }
    }
}
