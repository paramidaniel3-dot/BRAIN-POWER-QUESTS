package com.example.brainpowerquests;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Pre-fill existing data if it's there
        SharedPreferences sharedPref = getSharedPreferences("UserProfile", Context.MODE_PRIVATE);
        
        EditText editName = findViewById(R.id.editName);
        EditText editAge = findViewById(R.id.editAge);
        EditText editGender = findViewById(R.id.editGender);
        EditText editAddress = findViewById(R.id.editAddress);
        EditText editSchool = findViewById(R.id.editSchool);
        EditText editYearLevel = findViewById(R.id.editYearLevel);
        Button submitProfileBtn = findViewById(R.id.submitProfileBtn);

        // Fill in fields if user is already registered (e.g. they came back here)
        editName.setText(sharedPref.getString("name", ""));
        editAge.setText(sharedPref.getString("age", ""));
        editGender.setText(sharedPref.getString("gender", ""));
        editAddress.setText(sharedPref.getString("address", ""));
        editSchool.setText(sharedPref.getString("school", ""));
        editYearLevel.setText(sharedPref.getString("yearLevel", ""));

        submitProfileBtn.setOnClickListener(v -> {
            String name = editName.getText().toString().trim();
            String age = editAge.getText().toString().trim();
            String gender = editGender.getText().toString().trim();
            String address = editAddress.getText().toString().trim();
            String school = editSchool.getText().toString().trim();
            String yearLevel = editYearLevel.getText().toString().trim();

            if (name.isEmpty() || age.isEmpty() || gender.isEmpty() || address.isEmpty() || school.isEmpty() || yearLevel.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Save profile data
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("name", name);
                editor.putString("age", age);
                editor.putString("gender", gender);
                editor.putString("address", address);
                editor.putString("school", school);
                editor.putString("yearLevel", yearLevel);
                editor.apply();

                Toast.makeText(this, "Profile Saved! Welcome, " + name, Toast.LENGTH_LONG).show();
                
                startActivity(new Intent(ProfileActivity.this, MainMenuActivity.class));
                finish();
            }
        });
    }
}
