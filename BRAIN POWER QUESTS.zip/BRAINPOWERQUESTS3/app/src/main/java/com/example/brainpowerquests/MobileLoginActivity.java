package com.example.brainpowerquests;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MobileLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile_login);

        EditText phoneInput = findViewById(R.id.phoneInput);
        Button submitBtn = findViewById(R.id.submitBtn);
        Button backBtn = findViewById(R.id.backBtn);

        submitBtn.setOnClickListener(v -> {
            String phone = phoneInput.getText().toString().trim();

            if (phone.isEmpty()) {
                Toast.makeText(this, "Please enter your mobile number", Toast.LENGTH_SHORT).show();
            } else if (phone.length() < 10) {
                Toast.makeText(this, "Please enter a valid mobile number", Toast.LENGTH_SHORT).show();
            } else {
                // Save mobile number and login status to SharedPreferences
                SharedPreferences sharedPref = getSharedPreferences("UserAuth", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("mobileNumber", phone);
                editor.putBoolean("isLoggedIn", true);
                editor.apply();

                // After successful registration, go to Profile Information
                Intent intent = new Intent(MobileLoginActivity.this, ProfileActivity.class);
                startActivity(intent);
                finish();
            }
        });

        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                finish(); // Returns to the Welcome screen
            });
        }
    }
}
