package com.example.brainpowerquests;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HistoryTopicsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_topics);

        setupButton(R.id.ancientHistoryBtn, "Ancient History");
        setupButton(R.id.warsConflictsBtn, "Wars & Conflicts");
        setupButton(R.id.leadersPeopleBtn, "Leaders & Important People");
        setupButton(R.id.asianPhilippineBtn, "Asian & Philippine History");

        Button backBtn = findViewById(R.id.backBtn);
        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                finish(); // Returns to Subject Selection
            });
        }
    }

    private void setupButton(int id, String topicName) {
        Button btn = findViewById(id);
        if (btn != null) {
            btn.setOnClickListener(v -> {
                Intent intent = new Intent(HistoryTopicsActivity.this, QuizActivity.class);
                intent.putExtra("topic", topicName);
                startActivity(intent);
            });
        }
    }
}
