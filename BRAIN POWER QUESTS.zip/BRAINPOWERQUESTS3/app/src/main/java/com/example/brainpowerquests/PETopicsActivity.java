package com.example.brainpowerquests;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class PETopicsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pe_topics);

        setupButton(R.id.fitnessBtn, "Fitness & Exercise");
        setupButton(R.id.sportsBtn, "Sports");
        setupButton(R.id.healthWellnessBtn, "Health & Wellness Movement & Skills");
        setupButton(R.id.nutritionBtn, "Nutrition & Lifestyle");

        Button backBtn = findViewById(R.id.backBtn);
        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                finish(); // Returns to Subject Selection
            });
        }
    }

    private void setupButton(int id, String topicName) {
        Button btn = findViewById(id);
        if (btn != null) {
            btn.setOnClickListener(v -> {
                Intent intent = new Intent(PETopicsActivity.this, QuizActivity.class);
                intent.putExtra("topic", topicName);
                startActivity(intent);
            });
        }
    }
}
