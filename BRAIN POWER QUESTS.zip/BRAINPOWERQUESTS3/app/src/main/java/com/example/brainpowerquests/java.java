package com.example.brainpowerquests;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class java extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Check if user is logged in
        SharedPreferences authPref = getSharedPreferences("UserAuth", Context.MODE_PRIVATE);
        boolean isLoggedIn = authPref.getBoolean("isLoggedIn", false);

        if (isLoggedIn) {
            // 2. Check if profile is complete
            SharedPreferences profilePref = getSharedPreferences("UserProfile", Context.MODE_PRIVATE);
            String name = profilePref.getString("name", "");

            if (!name.isEmpty()) {
                // Already logged in and profile exists -> Go to Main Menu
                startActivity(new Intent(this, MainMenuActivity.class));
                finish();
                return;
            } else {
                // Logged in but NO profile -> Go to Profile Activity
                startActivity(new Intent(this, ProfileActivity.class));
                finish();
                return;
            }
        }

        // If not logged in, show the welcome screen
        setContentView(R.layout.activity_java);

        Button googleBtn = findViewById(R.id.googleBtn);
        Button mobileBtn = findViewById(R.id.mobileBtn);

        if (googleBtn != null) {
            googleBtn.setOnClickListener(v -> {
                startActivity(new Intent(java.this, GoogleLoginActivity.class));
            });
        }

        if (mobileBtn != null) {
            mobileBtn.setOnClickListener(v -> {
                startActivity(new Intent(java.this, MobileLoginActivity.class));
            });
        }
    }
}
