package com.example.brainpowerquests;

import java.util.ArrayList;
import java.util.List;

public class QuizDatabase {

    public static List<Question> getQuestions(String topic) {
        List<Question> list = new ArrayList<>();
        if (topic == null) return list;

        switch (topic) {
            case "Arithmetic":
                list.add(new Question("Solve: (25 * 14) / 7 + 125 - 45", "130", "140", "125", "115", 1));
                list.add(new Question("What is 0.75 of 480 plus 1/4 of 120?", "360", "390", "400", "410", 2));
                list.add(new Question("Evaluate: 15² - 12² + 5³", "206", "196", "216", "226", 1));
                list.add(new Question("Square root of (144 + 25) * 2 is?", "13", "34", "26", "30", 3));
                list.add(new Question("What is 45% of 2000 minus 150?", "900", "850", "750", "800", 3));
                list.add(new Question("Find 3/8 of 640 and add 120.", "240", "360", "340", "320", 2));
                list.add(new Question("Solve: (18 * 5) + (24 * 4) - (15 * 6)", "96", "106", "86", "76", 1));
                list.add(new Question("Evaluate: 1.25 * 80 + 0.5 * 150", "150", "175", "165", "185", 2));
                list.add(new Question("Calculate: 2⁶ + 3⁴ - 10²", "55", "35", "25", "45", 4));
                list.add(new Question("Solve: (500 / 25) * (144 / 12)", "240", "220", "260", "200", 1));
                list.add(new Question("What is 17 * 19 + 23?", "326", "346", "316", "356", 2));
                list.add(new Question("Solve: 0.6 * 1200 / 4", "160", "200", "180", "150", 3));
                list.add(new Question("Calculate: 2/5 of 500 + 3/4 of 400", "400", "600", "450", "500", 4));
                list.add(new Question("Solve: (14 * 15) - (12 * 11)", "68", "88", "58", "78", 4));
                list.add(new Question("Evaluate: 9² + 8² + 7²", "194", "184", "204", "174", 1));
                list.add(new Question("Calculate: (1000 - 450) / 11", "55", "50", "45", "60", 2));
                list.add(new Question("What is 12% of 5000 / 20?", "40", "25", "30", "35", 3));
                list.add(new Question("Evaluate: 1.5 * 200 - 0.75 * 100", "225", "250", "200", "275", 1));
                list.add(new Question("Solve: (25 + 35) * (15 - 5) / 2", "250", "300", "350", "400", 2));
                list.add(new Question("Calculate: 144 / 12 * 15 + 20", "180", "220", "200", "210", 3));
                list.add(new Question("Find 2/3 of 270 plus 1/5 of 1000.", "360", "400", "380", "350", 3));
                list.add(new Question("Evaluate: 18 * 18 - 15 * 15", "109", "99", "89", "79", 2));
                list.add(new Question("Solve: (120 * 3) / 9 + 40", "70", "90", "80", "60", 3));
                list.add(new Question("Calculate: 0.8 * 250 + 150", "350", "300", "400", "320", 1));
                list.add(new Question("What is 5! (factorial) minus 100?", "10", "30", "40", "20", 4));
                list.add(new Question("Find the cube root of 216 multiplied by 5.", "25", "30", "35", "40", 2));
                list.add(new Question("Solve: (45 * 2) + (30 * 3) - 150", "20", "40", "10", "30", 2));
                list.add(new Question("What is 75% of 800 - 20% of 1000?", "300", "500", "350", "400", 4));
                list.add(new Question("Calculate: 1.1 * 500 + 450", "950", "1050", "900", "1000", 4));
                list.add(new Question("Evaluate: (15² + 5²) / 10", "20", "30", "15", "25", 4));
                break;

            case "Algebra 1 & 2":
                list.add(new Question("Solve for x: 3x + 5 = 20", "5", "4", "6", "3", 1));
                list.add(new Question("What is the slope of the line y = 2x + 3?", "2", "3", "1", "0", 1));
                list.add(new Question("Simplify: (x^2)^3", "x^5", "x^6", "x^1", "x^8", 2));
                list.add(new Question("Solve for x: x^2 = 16", "4 or -4", "4", "-4", "8", 1));
                list.add(new Question("What is the value of f(2) if f(x) = x^2 + 1?", "5", "4", "3", "6", 1));
                list.add(new Question("Solve for y: 2y - 10 = 14", "12", "10", "14", "8", 1));
                list.add(new Question("What is (x + 2)(x - 2)?", "x² - 4", "x² + 4", "x² - 2x", "x² + 4x", 1));
                list.add(new Question("Find the value of x: 5x/2 = 10", "4", "5", "2", "8", 1));
                list.add(new Question("Factor: x^2 + 5x + 6", "(x+2)(x+3)", "(x+1)(x+6)", "(x+5)(x+1)", "(x-2)(x-3)", 1));
                list.add(new Question("If 3x + 4 = 19, what is x?", "5", "4", "6", "7", 1));
                list.add(new Question("Simplify: 4(x + 3) - 2x", "2x + 12", "2x + 3", "6x + 12", "4x + 12", 1));
                list.add(new Question("What is the value of 3^4?", "81", "27", "64", "12", 1));
                list.add(new Question("Solve for x: |x - 5| = 3", "8 or 2", "8", "2", "5 or -5", 1));
                list.add(new Question("What is the discriminant of x^2 + 4x + 4 = 0?", "0", "16", "4", "8", 1));
                list.add(new Question("Solve: 2(x - 3) = 14", "10", "7", "11", "13", 1));
                list.add(new Question("Find the midpoint of (2, 4) and (6, 8)", "(4, 6)", "(3, 5)", "(8, 12)", "(4, 4)", 1));
                list.add(new Question("What is the square root of 169?", "13", "11", "12", "14", 1));
                list.add(new Question("Simplify: (2x^3)(4x^2)", "8x^5", "8x^6", "6x^5", "6x^6", 1));
                list.add(new Question("If y = mx + b, what does 'b' represent?", "y-intercept", "slope", "x-intercept", "origin", 1));
                list.add(new Question("Solve for x: 7x - 3 = 4x + 9", "4", "3", "5", "2", 1));
                list.add(new Question("What is the value of 5! (factorial)?", "120", "60", "24", "100", 1));
                list.add(new Question("Simplify: sqrt(50)", "5√2", "2√5", "10√5", "5√10", 1));
                list.add(new Question("Solve: x^2 - 9 = 0", "3 or -3", "3", "-3", "9 or -9", 1));
                list.add(new Question("If f(x) = 2x - 5, find f(10)", "15", "25", "20", "10", 1));
                list.add(new Question("What is the sum of (2x + 3) and (5x - 7)?", "7x - 4", "7x + 10", "10x - 4", "3x - 10", 1));
                list.add(new Question("Find the slope of the line through (1, 2) and (3, 6)", "2", "3", "4", "1", 1));
                list.add(new Question("Solve for x: 3(x + 1) = 2x + 7", "4", "5", "3", "6", 1));
                list.add(new Question("What is the GCF of 12 and 18?", "6", "3", "2", "12", 1));
                list.add(new Question("Simplify: x^5 / x^2", "x³", "x⁷", "x¹⁰", "x²·⁵", 1));
                list.add(new Question("If a = 2 and b = 3, find a^2 + b^2", "13", "10", "5", "25", 1));
                break;

            case "Geometry":
                list.add(new Question("What is the sum of angles in a triangle?", "180°", "360°", "90°", "270°", 1));
                list.add(new Question("Area of a circle is?", "πr²", "2πr", "πd", "bh/2", 1));
                list.add(new Question("A triangle with all sides equal is?", "Equilateral", "Isosceles", "Scalene", "Right", 1));
                list.add(new Question("How many sides does a hexagon have?", "6", "5", "8", "4", 1));
                list.add(new Question("Pythagorean theorem formula?", "a² + b² = c²", "a + b = c", "E = mc²", "A = lw", 1));
                list.add(new Question("Area of a rectangle with length 10 and width 5?", "50", "15", "30", "25", 1));
                list.add(new Question("Perimeter of a square with side 4?", "16", "8", "12", "20", 1));
                list.add(new Question("A polygon with 5 sides is called?", "Pentagon", "Hexagon", "Heptagon", "Octagon", 1));
                list.add(new Question("What is the measure of a right angle?", "90°", "180°", "45°", "0°", 1));
                list.add(new Question("Volume of a cube with side 3?", "27", "9", "18", "12", 1));
                list.add(new Question("How many degrees are in a circle?", "360°", "180°", "90°", "270°", 1));
                list.add(new Question("Two lines that never meet are?", "Parallel", "Perpendicular", "Intersecting", "Adjacent", 1));
                list.add(new Question("An angle greater than 90° but less than 180° is?", "Obtuse", "Acute", "Right", "Straight", 1));
                list.add(new Question("What is the diameter if the radius is 7?", "14", "7", "21", "49", 1));
                list.add(new Question("Area of a triangle with base 6 and height 4?", "12", "24", "10", "18", 1));
                list.add(new Question("A 10-sided polygon is a?", "Decagon", "Nonagon", "Dodecagon", "Heptagon", 1));
                list.add(new Question("Sum of interior angles of a quadrilateral?", "360°", "180°", "540°", "720°", 1));
                list.add(new Question("Surface area of a sphere formula?", "4πr²", "πr²", "2πr", "4/3πr³", 1));
                list.add(new Question("What is a triangle with two equal sides called?", "Isosceles", "Equilateral", "Scalene", "Right", 1));
                list.add(new Question("Complementary angles sum to?", "90°", "180°", "45°", "360°", 1));
                list.add(new Question("Supplementary angles sum to?", "180°", "90°", "270°", "360°", 1));
                list.add(new Question("The longest side of a right triangle is the?", "Hypotenuse", "Adjacent", "Opposite", "Leg", 1));
                list.add(new Question("Volume of a cylinder formula?", "πr²h", "2πrh", "πdh", "1/3πr²h", 1));
                list.add(new Question("A line segment connecting two points on a circle passing through the center?", "Diameter", "Radius", "Chord", "Tangent", 1));
                list.add(new Question("How many faces does a cube have?", "6", "8", "12", "4", 1));
                list.add(new Question("Area of a trapezoid formula?", "(a+b)h/2", "ab/h", "ah + bh", "2(a+b)h", 1));
                list.add(new Question("Each angle in an equilateral triangle is?", "60°", "90°", "45°", "120°", 1));
                list.add(new Question("A polygon with 8 sides?", "Octagon", "Hexagon", "Heptagon", "Nonagon", 1));
                list.add(new Question("Perimeter of a rectangle formula?", "2(l+w)", "l*w", "2l + w", "l + 2w", 1));
                list.add(new Question("Diagonal of a square with side 's'?", "s√2", "s²", "2s", "s/√2", 1));
                break;

            case "Trigonometry":
                list.add(new Question("What is sin(90°)?", "1", "0", "0.5", "-1", 1));
                list.add(new Question("In a right triangle, tan(θ) is?", "Opposite/Adjacent", "Opposite/Hypotenuse", "Adjacent/Hypotenuse", "Hypotenuse/Opposite", 1));
                list.add(new Question("What is cos(0°)?", "1", "0", "-1", "0.5", 1));
                list.add(new Question("The reciprocal of sine is?", "Cosecant", "Secant", "Cotangent", "Cosine", 1));
                list.add(new Question("sin²(θ) + cos²(θ) = ?", "1", "0", "2", "-1", 1));
                list.add(new Question("What is cos(90°)?", "0", "1", "-1", "0.5", 1));
                list.add(new Question("In a right triangle, cos(θ) is?", "Adjacent/Hypotenuse", "Opposite/Hypotenuse", "Opposite/Adjacent", "Adjacent/Opposite", 1));
                list.add(new Question("What is tan(45°)?", "1", "0", "sqrt(3)", "0.5", 1));
                list.add(new Question("What is sin(30°)?", "0.5", "1", "0", "sqrt(3)/2", 1));
                list.add(new Question("Reciprocal of cosine is?", "Secant", "Cosecant", "Cotangent", "Tangent", 1));
                list.add(new Question("Reciprocal of tangent is?", "Cotangent", "Secant", "Cosecant", "Cosine", 1));
                list.add(new Question("What is sin(0°)?", "0", "1", "-1", "0.5", 1));
                list.add(new Question("Value of cos(60°)?", "0.5", "sqrt(3)/2", "1", "0", 1));
                list.add(new Question("tan(θ) = sin(θ) / ?", "cos(θ)", "sec(θ)", "1", "cot(θ)", 1));
                list.add(new Question("Law of Sines formula?", "a/sinA = b/sinB", "a/cosA = b/cosB", "a² = b² + c²", "sinA/a = cosB/b", 1));
                list.add(new Question("What is the value of π in degrees?", "180°", "360°", "90°", "270°", 1));
                list.add(new Question("sin(180°) is?", "0", "1", "-1", "Undefined", 1));
                list.add(new Question("cos(180°) is?", "-1", "0", "1", "0.5", 1));
                list.add(new Question("1 + tan²(θ) = ?", "sec²(θ)", "csc²(θ)", "sin²(θ)", "cos²(θ)", 1));
                list.add(new Question("1 + cot²(θ) = ?", "csc²(θ)", "sec²(θ)", "tan²(θ)", "1", 1));
                list.add(new Question("What is arcsin(1)?", "90°", "0°", "180°", "45°", 1));
                list.add(new Question("Amplitude of y = 3sin(x)?", "3", "1", "2π", "0", 1));
                list.add(new Question("Period of y = sin(x)?", "2π", "π", "4π", "π/2", 1));
                list.add(new Question("cos(-θ) is equal to?", "cos(θ)", "-cos(θ)", "sin(θ)", "-sin(θ)", 1));
                list.add(new Question("sin(-θ) is equal to?", "-sin(θ)", "sin(θ)", "cos(θ)", "-cos(θ)", 1));
                list.add(new Question("tan(90°) is?", "Undefined", "0", "1", "-1", 1));
                list.add(new Question("What is sin(45°)?", "√2/2", "1/2", "√3/2", "1", 1));
                list.add(new Question("Law of Cosines formula?", "c² = a² + b² - 2ab cosC", "c² = a² + b² + 2ab cosC", "a/sinA = b/sinB", "sin² + cos² = 1", 1));
                list.add(new Question("Value of sin²(30°) + cos²(30°)?", "1", "0", "0.5", "2", 1));
                list.add(new Question("In which quadrant is sine positive and cosine negative?", "II", "I", "III", "IV", 1));
                break;

            case "Spelling master":
                list.add(new Question("Which is the correct spelling?", "Accommodation", "Acomodation", "Accomodation", "Acommodation", 1));
                list.add(new Question("Which is the correct spelling?", "Necessary", "Neccessary", "Necesary", "Neccessery", 1));
                list.add(new Question("Which is the correct spelling?", "Environment", "Enviroment", "Environement", "Envirenment", 1));
                list.add(new Question("Which is the correct spelling?", "Separate", "Seperate", "Seprate", "Sepparate", 1));
                list.add(new Question("Which is the correct spelling?", "Definitely", "Definately", "Definitly", "Definatly", 1));
                list.add(new Question("Which is the correct spelling?", "Calendar", "Calender", "Calander", "Calendur", 1));
                list.add(new Question("Which is the correct spelling?", "Parallel", "Paralell", "Parellel", "Parallell", 1));
                list.add(new Question("Which is the correct spelling?", "Business", "Buisness", "Bussiness", "Busyness", 1));
                list.add(new Question("Which is the correct spelling?", "Rhythm", "Rythm", "Rhythum", "Rythum", 1));
                list.add(new Question("Which is the correct spelling?", "Foreign", "Foriegn", "Forein", "Forreign", 1));
                list.add(new Question("Which is the correct spelling?", "Receive", "Recieve", "Receve", "Reseive", 1));
                list.add(new Question("Which is the correct spelling?", "Believe", "Beleive", "Belive", "Beleeve", 1));
                list.add(new Question("Which is the correct spelling?", "Occurred", "Ocured", "Occured", "Ocurred", 1));
                list.add(new Question("Which is the correct spelling?", "Embarrass", "Embarass", "Ebarrass", "Embaras", 1));
                list.add(new Question("Which is the correct spelling?", "Knowledge", "Knowlege", "Knowlidge", "Knwoledge", 1));
                list.add(new Question("Which is the correct spelling?", "Maintenance", "Maintainance", "Maintenence", "Maintenence", 1));
                list.add(new Question("Which is the correct spelling?", "Beginning", "Begining", "Begining", "Begining", 1));
                list.add(new Question("Which is the correct spelling?", "Immediately", "Imediatly", "Immediatly", "Immeditely", 1));
                list.add(new Question("Which is the correct spelling?", "Relevant", "Relavent", "Relevante", "Relevent", 1));
                list.add(new Question("Which is the correct spelling?", "Committee", "Comitee", "Commitee", "Committee", 4));
                list.add(new Question("Which is the correct spelling?", "Guarantee", "Gaurantee", "Guaranty", "Guarrantee", 1));
                list.add(new Question("Which is the correct spelling?", "Harrass", "Harass", "Harrass", "Harass", 2));
                list.add(new Question("Which is the correct spelling?", "Privilege", "Priviledge", "Privelege", "Privilidge", 1));
                list.add(new Question("Which is the correct spelling?", "Tomorrow", "Tommorow", "Tomorrow", "Tommorrow", 3));
                list.add(new Question("Which is the correct spelling?", "Jewelry", "Jewlery", "Jewellry", "Jewellery", 1));
                list.add(new Question("Which is the correct spelling?", "Queue", "Que", "Queu", "Qewe", 1));
                list.add(new Question("Which is the correct spelling?", "Schedule", "Scedule", "Shedule", "Schedulle", 1));
                list.add(new Question("Which is the correct spelling?", "Vacuum", "Vaccum", "Vacum", "Vacuume", 1));
                list.add(new Question("Which is the correct spelling?", "Twelfth", "Twelth", "Twelvth", "Twelft", 1));
                list.add(new Question("Which is the correct spelling?", "Millennium", "Millenium", "Milenium", "Milennium", 1));
                break;

            case "Grammar hunter":
                list.add(new Question("They ___ going to the park.", "are", "is", "am", "was", 1));
                list.add(new Question("She ___ her homework yesterday.", "did", "does", "done", "do", 1));
                list.add(new Question("Neither of the boys ___ finished.", "has", "have", "are", "were", 1));
                list.add(new Question("If I ___ you, I would go.", "were", "was", "am", "be", 1));
                list.add(new Question("He is taller ___ me.", "than", "then", "from", "to", 1));
                list.add(new Question("The cake was divided ___ the four children.", "among", "between", "with", "for", 1));
                list.add(new Question("I have been waiting here ___ two hours.", "for", "since", "from", "during", 1));
                list.add(new Question("Each of the students ___ a book.", "has", "have", "are", "is", 1));
                list.add(new Question("I look forward to ___ you.", "meeting", "meet", "met", "be meeting", 1));
                list.add(new Question("She speaks English ___.", "well", "good", "betterly", "bestly", 1));
                list.add(new Question("He ___ to the gym every day.", "goes", "go", "going", "gone", 1));
                list.add(new Question("The dog wagged ___ tail.", "its", "it's", "his", "their", 1));
                list.add(new Question("Whose book is this? It's ___.", "mine", "my", "me", "I", 1));
                list.add(new Question("By the time we arrived, they ___.", "had left", "have left", "left", "was left", 1));
                list.add(new Question("I don't have ___ money.", "any", "some", "no", "many", 1));
                list.add(new Question("She is the ___ of the two sisters.", "taller", "tallest", "more tall", "most tall", 1));
                list.add(new Question("You ___ better study hard.", "had", "would", "should", "will", 1));
                list.add(new Question("I ___ seen that movie yet.", "haven't", "hasn't", "didn't", "don't", 1));
                list.add(new Question("The news ___ not good.", "is", "are", "were", "am", 1));
                list.add(new Question("Who ___ you talking to?", "were", "was", "is", "are", 1));
                list.add(new Question("I suggest that he ___ early.", "leave", "leaves", "left", "should leave", 1));
                list.add(new Question("I'm not used to ___ early.", "waking up", "wake up", "woke up", "be waking", 1));
                list.add(new Question("The person ___ stole my bike was caught.", "who", "whom", "whose", "which", 1));
                list.add(new Question("This is the house ___ I grew up.", "where", "which", "that", "in that", 1));
                list.add(new Question("If it rains, we ___ at home.", "will stay", "stay", "would stay", "stayed", 1));
                list.add(new Question("He avoided ___ the question.", "answering", "to answer", "answer", "answered", 1));
                list.add(new Question("Neither the teacher nor the students ___ there.", "were", "was", "is", "am", 1));
                list.add(new Question("I wish I ___ richer.", "were", "was", "am", "be", 1));
                list.add(new Question("The police ___ investigating the crime.", "are", "is", "was", "has", 1));
                list.add(new Question("It's time you ___ home.", "went", "go", "gone", "going", 1));
                break;

            case "Punctuation Fixer":
                list.add(new Question("Which sentence is punctuated correctly?", "I like apples, oranges, and bananas.", "I like apples oranges and bananas", "I like apples, oranges and, bananas", "I like apples oranges, and bananas", 1));
                list.add(new Question("Which is correct?", "Its raining outside.", "It's raining outside.", "Its' raining outside.", "It's' raining outside.", 2));
                list.add(new Question("Which is correct?", "She said, \"Hello!\"", "She said \"Hello!\"", "She said, Hello!", "She said: \"Hello!\"", 1));
                list.add(new Question("Which is correct?", "Where are you going?", "Where are you going.", "Where are you going!", "Where are you going,", 1));
                list.add(new Question("Which is correct?", "I'm a student; he's a teacher.", "I'm a student, he's a teacher.", "I'm a student he's a teacher.", "I'm a student: he's a teacher.", 1));
                list.add(new Question("Which is correct?", "The boys' room is messy.", "The boys room is messy.", "The boy's room is messy.", "The boys room's is messy.", 1));
                list.add(new Question("Which is correct?", "He's from Paris, France.", "He's from Paris France.", "He's from Paris, France", "He's from, Paris France.", 1));
                list.add(new Question("Which is correct?", "Wait! Come back.", "Wait Come back.", "Wait, Come back.", "Wait? Come back.", 1));
                list.add(new Question("Which is correct?", "Dr. Smith is here.", "Dr Smith is here.", "Dr, Smith is here.", "Doctor. Smith is here.", 1));
                list.add(new Question("Which is correct?", "I have three items: pens, paper, and ink.", "I have three items, pens, paper and ink.", "I have three items pens, paper, and ink.", "I have three items; pens, paper, and ink.", 1));
                list.add(new Question("Which is correct?", "Yes, I will go.", "Yes I will go.", "Yes. I will go.", "Yes: I will go.", 1));
                list.add(new Question("Which is correct?", "John's car is red.", "Johns car is red.", "Johns' car is red.", "John car is red.", 1));
                list.add(new Question("Which is correct?", "Twenty-one people came.", "Twenty one people came.", "Twentyone people came.", "Twenty,one people came.", 1));
                list.add(new Question("Which is correct?", "They're over there.", "Their over there.", "There over there.", "Theyre over there.", 1));
                list.add(new Question("Which is correct?", "Can you help me, please?", "Can you help me please?", "Can you help me. please?", "Can you help me: please?", 1));
                list.add(new Question("Which is correct?", "He said he was \"tired.\"", "He said he was \"tired\".", "He said he was tired.", "He said he was: tired.", 1));
                list.add(new Question("Which is correct?", "My mother, a doctor, is busy.", "My mother a doctor is busy.", "My mother, a doctor is busy.", "My mother a doctor, is busy.", 1));
                list.add(new Question("Which is correct?", "Oh! What a surprise.", "Oh What a surprise.", "Oh, What a surprise.", "Oh? What a surprise.", 1));
                list.add(new Question("Which is correct?", "I'll be there at 5:00 p.m.", "I'll be there at 5:00 pm", "I'll be there at 5.00 p.m.", "I'll be there at 5:00 pm.", 1));
                list.add(new Question("Which is correct?", "Run, John, run!", "Run John run!", "Run, John run.", "Run John, run!", 1));
                list.add(new Question("Which is correct?", "However, he was late.", "Base however he was late.", "However. he was late.", "However: he was late.", 1));
                list.add(new Question("Which is correct?", "Whose is this?", "Who's is this?", "Whoses is this?", "Who is this?", 1));
                list.add(new Question("Which is correct?", "Let's go.", "Lets go.", "Lets' go.", "Let's' go.", 1));
                list.add(new Question("Which is correct?", "I like tea; she likes coffee.", "I like tea, she likes coffee.", "I like tea she likes coffee.", "I like tea: she likes coffee.", 1));
                list.add(new Question("Which is correct?", "Help me!", "Help me.", "Help me?", "Help me,", 1));
                list.add(new Question("Which is correct?", "Dear Mr. President,", "Dear Mr President", "Dear, Mr President,", "Dear Mr. President", 1));
                list.add(new Question("Which is correct?", "No, thank you.", "No thank you.", "No. thank you.", "No; thank you.", 1));
                list.add(new Question("Which is correct?", "Stop, look, and listen.", "Stop look and listen.", "Stop look, and listen.", "Stop, look and listen.", 1));
                list.add(new Question("Which is correct?", "I'm going home.", "Im going home.", "I'am going home.", "I am going home", 1));
                list.add(new Question("Which is correct?", "You're welcome.", "Your welcome.", "Youre welcome.", "You're' welcome.", 1));
                break;

            case "Arrange The Word":
                list.add(new Question("Rearrange: P P L E A", "APPLE", "PEPAL", "ALEPP", "LAPPE", 1));
                list.add(new Question("Rearrange: N A N A B A", "BANANA", "BANAN", "NABANA", "BANNAN", 1));
                list.add(new Question("Rearrange: O R A N G E", "ORANGE", "ORANG", "ONGAR", "ORGANE", 1));
                list.add(new Question("Rearrange: C O M P U T E R", "COMPUTER", "COMPUTOR", "COMTUPER", "COMPREUT", 1));
                list.add(new Question("Rearrange: E N G L I S H", "ENGLISH", "ENGLIS", "ENGILSH", "ENGHILS", 1));
                list.add(new Question("Rearrange: S C H O O L", "SCHOOL", "SCHOL", "SHCOOL", "SOHOOL", 1));
                list.add(new Question("Rearrange: T E A C H E R", "TEACHER", "TEACHOR", "TAECHER", "TEAHCER", 1));
                list.add(new Question("Rearrange: S T U D E N T", "STUDENT", "STUDANT", "STUEDNT", "STUNDET", 1));
                list.add(new Question("Rearrange: K I T C H E N", "KITCHEN", "KITCHAN", "KITHCEN", "KITCENH", 1));
                list.add(new Question("Rearrange: G A R D E N", "GARDEN", "GARDAN", "GARNDE", "GADREN", 1));
                list.add(new Question("Rearrange: B E A U T I F U L", "BEAUTIFUL", "BEAUTIFULL", "BUETIFUL", "BEAUTIFULY", 1));
                list.add(new Question("Rearrange: H A P P I N E S S", "HAPPINESS", "HAPPINES", "HAPINESS", "HAPPINNESS", 1));
                list.add(new Question("Rearrange: M O U N T A I N", "MOUNTAIN", "MOUNTAN", "MOUNTIAN", "MOUTAIN", 1));
                list.add(new Question("Rearrange: V I L L A G E", "VILLAGE", "VILAGE", "VALLEGE", "VILLEGE", 1));
                list.add(new Question("Rearrange: J O U R N E Y", "JOURNEY", "JOURNY", "JOURNNEY", "JURNEY", 1));
                list.add(new Question("Rearrange: F R I E N D", "FRIEND", "FREIND", "FRIND", "FREND", 1));
                list.add(new Question("Rearrange: F A M I L Y", "FAMILY", "FAMLY", "FAMILIE", "FAMILLY", 1));
                list.add(new Question("Rearrange: M O R N I N G", "MORNING", "MORNINGS", "MORNNIG", "MORNIG", 1));
                list.add(new Question("Rearrange: E V E N I N G", "EVENING", "EVENIN", "EVNNING", "EVENNING", 1));
                list.add(new Question("Rearrange: W E A T H E R", "WEATHER", "WHETHER", "WEATER", "WAETHER", 1));
                list.add(new Question("Rearrange: B I C Y C L E", "BICYCLE", "BYCICLE", "BICYCCLE", "BICYCEL", 1));
                list.add(new Question("Rearrange: H O L I D A Y", "HOLIDAY", "HOLLIDAY", "HOLIDAYE", "HOLIDY", 1));
                list.add(new Question("Rearrange: L I B R A R Y", "LIBRARY", "LIBARY", "LIBRERY", "LIBBARY", 1));
                list.add(new Question("Rearrange: M U S E U M", "MUSEUM", "MUSUEM", "MUSEAM", "MUSUAM", 1));
                list.add(new Question("Rearrange: C I T Y", "CITY", "CITTY", "CITIE", "CITEY", 1));
                list.add(new Question("Rearrange: C O U N T R Y", "COUNTRY", "CONTRY", "COUNTREY", "COUNTERY", 1));
                list.add(new Question("Rearrange: O C E A N", "OCEAN", "OCEN", "OCEANIC", "OCANE", 1));
                list.add(new Question("Rearrange: P L A N E T", "PLANET", "PLANNET", "PLANT", "PLANNIT", 1));
                list.add(new Question("Rearrange: S T A R", "STAR", "STARE", "STARR", "SART", 1));
                list.add(new Question("Rearrange: W O R L D", "WORLD", "WORD", "WOLRD", "WROLD", 1));
                break;

            case "Physics":
                list.add(new Question("What is the SI unit of force?", "Newton", "Joule", "Watt", "Pascal", 1));
                list.add(new Question("What is the acceleration due to gravity on Earth?", "9.8 m/s²", "10.5 m/s²", "8.9 m/s²", "7.2 m/s²", 1));
                list.add(new Question("Which law states that for every action, there is an equal and opposite reaction?", "Newton's Third Law", "Newton's First Law", "Newton's Second Law", "Law of Inertia", 1));
                list.add(new Question("What is the formula for work?", "Force × Distance", "Mass × Acceleration", "Force / Area", "Mass × Velocity", 1));
                list.add(new Question("What is the approximate speed of light in a vacuum?", "300,000 km/s", "150,000 km/s", "450,000 km/s", "1,000,000 km/s", 1));
                list.add(new Question("What is the unit of electric current?", "Ampere", "Volt", "Ohm", "Coulomb", 1));
                list.add(new Question("The Law of Conservation of Energy is also known as:", "First Law of Thermodynamics", "Second Law of Thermodynamics", "Ohm's Law", "Hooke's Law", 1));
                list.add(new Question("What is the SI unit of power?", "Watt", "Joule", "Newton", "Volt", 1));
                list.add(new Question("What is the formula for density?", "Mass / Volume", "Mass × Volume", "Volume / Mass", "Weight × Gravity", 1));
                list.add(new Question("Who formulated the law of universal gravitation?", "Isaac Newton", "Albert Einstein", "Galileo Galilei", "Johannes Kepler", 1));
                list.add(new Question("What is the unit of electrical resistance?", "Ohm", "Watt", "Ampere", "Volt", 1));
                list.add(new Question("What instrument is used to measure atmospheric pressure?", "Barometer", "Thermometer", "Hygrometer", "Anemometer", 1));
                list.add(new Question("Energy possessed by an object due to its motion is:", "Kinetic Energy", "Potential Energy", "Thermal Energy", "Chemical Energy", 1));
                list.add(new Question("What is the boiling point of water at sea level in Celsius?", "100°C", "0°C", "212°C", "50°C", 1));
                list.add(new Question("What is the SI unit of frequency?", "Hertz", "Decibel", "Joule", "Newton", 1));
                list.add(new Question("Which color of visible light has the longest wavelength?", "Red", "Blue", "Violet", "Green", 1));
                list.add(new Question("The bending of light as it passes from one medium to another is called:", "Refraction", "Reflection", "Diffraction", "Dispersion", 1));
                list.add(new Question("What is the SI unit of energy?", "Joule", "Watt", "Newton", "Pascal", 1));
                list.add(new Question("Which state of matter has a definite volume but no definite shape?", "Liquid", "Solid", "Gas", "Plasma", 1));
                list.add(new Question("What is the formula for Ohm's Law?", "V = IR", "P = IV", "F = ma", "E = mc²", 1));
                list.add(new Question("The study of sound is called:", "Acoustics", "Optics", "Thermodynamics", "Mechanics", 1));
                list.add(new Question("What is the freezing point of water in Fahrenheit?", "32°F", "0°F", "100°F", "212°F", 1));
                list.add(new Question("The property of an object to resist changes in its state of motion is:", "Inertia", "Momentum", "Velocity", "Acceleration", 1));
                list.add(new Question("What type of lens converges light rays to a single point?", "Convex", "Concave", "Plane", "Cylindrical", 1));
                list.add(new Question("What is the SI unit of magnetic flux?", "Weber", "Tesla", "Henry", "Farad", 1));
                list.add(new Question("Which subatomic particle has a negative charge?", "Electron", "Proton", "Neutron", "Positron", 1));
                list.add(new Question("Acceleration is defined as the rate of change of:", "Velocity", "Distance", "Time", "Mass", 1));
                list.add(new Question("What is the value of absolute zero on the Kelvin scale?", "0 K", "-273 K", "100 K", "273 K", 1));
                list.add(new Question("The transfer of heat through direct contact is called:", "Conduction", "Convection", "Radiation", "Insulation", 1));
                list.add(new Question("What is the formula for linear momentum?", "p = mv", "F = ma", "W = Fd", "E = mgh", 1));
                break;

            case "Chemistry":
                list.add(new Question("What is the chemical symbol for Gold?", "Au", "Ag", "Fe", "Pb", 1));
                list.add(new Question("What is the atomic number of Hydrogen?", "1", "2", "8", "6", 1));
                list.add(new Question("Which gas is most abundant in the Earth's atmosphere?", "Nitrogen", "Oxygen", "Carbon Dioxide", "Argon", 1));
                list.add(new Question("What is the pH of pure water?", "7", "1", "14", "5", 1));
                list.add(new Question("What is the chemical formula for table salt?", "NaCl", "KCl", "MgCl2", "CaCl2", 1));
                list.add(new Question("Which element is known as the 'King of Elements'?", "Carbon", "Hydrogen", "Oxygen", "Gold", 1));
                list.add(new Question("What is the process of a solid turning directly into a gas?", "Sublimation", "Evaporation", "Condensation", "Melting", 1));
                list.add(new Question("Who is credited with the creation of the first periodic table?", "Dmitri Mendeleev", "Antoine Lavoisier", "Marie Curie", "John Dalton", 1));
                list.add(new Question("What are the horizontal rows in the periodic table called?", "Periods", "Groups", "Families", "Columns", 1));
                list.add(new Question("What are the vertical columns in the periodic table called?", "Groups", "Periods", "Rows", "Sections", 1));
                list.add(new Question("Which subatomic particle has a positive charge?", "Proton", "Neutron", "Electron", "Photon", 1));
                list.add(new Question("What type of bond involves the sharing of electron pairs between atoms?", "Covalent", "Ionic", "Metallic", "Hydrogen", 1));
                list.add(new Question("What is the chemical symbol for Iron?", "Fe", "Ir", "In", "I", 1));
                list.add(new Question("Which acid is found in lemons?", "Citric acid", "Acetic acid", "Hydrochloric acid", "Sulfuric acid", 1));
                list.add(new Question("What is the most reactive metal in the periodic table?", "Francium", "Sodium", "Potassium", "Lithium", 1));
                list.add(new Question("What is the common name for Nitrous Oxide?", "Laughing gas", "Tear gas", "Mustard gas", "Dry ice", 1));
                list.add(new Question("Which element is necessary for combustion to take place?", "Oxygen", "Nitrogen", "Hydrogen", "Carbon", 1));
                list.add(new Question("What is the hardest naturally occurring substance?", "Diamond", "Graphite", "Quartz", "Topaz", 1));
                list.add(new Question("A solution with a pH less than 7 is considered:", "Acidic", "Basic", "Neutral", "Alkaline", 1));
                list.add(new Question("What is the chemical symbol for Sodium?", "Na", "S", "So", "Sn", 1));
                list.add(new Question("What is the mass number of an atom with 6 protons and 6 neutrons?", "12", "6", "0", "18", 1));
                list.add(new Question("Which element has the symbol 'K'?", "Potassium", "Krypton", "Calcium", "Phosphorus", 1));
                list.add(new Question("What is the formula for water?", "H2O", "HO2", "H2O2", "OH", 1));
                list.add(new Question("Which metal is liquid at room temperature?", "Mercury", "Silver", "Copper", "Aluminum", 1));
                list.add(new Question("What is the study of carbon compounds called?", "Organic Chemistry", "Inorganic Chemistry", "Biochemistry", "Physical Chemistry", 1));
                list.add(new Question("What is the charge of a neutron?", "Neutral (0)", "Positive (+1)", "Negative (-1)", "Variable", 1));
                list.add(new Question("Which element is used in pencils?", "Graphite (Carbon)", "Lead", "Zinc", "Iron", 1));
                list.add(new Question("What is the chemical symbol for Silver?", "Ag", "Au", "Si", "Sr", 1));
                list.add(new Question("What is the main component of natural gas?", "Methane", "Methane", "Propane", "Butane", 1));
                list.add(new Question("Who discovered Radium and Polonium?", "Marie Curie", "Ernest Rutherford", "Niels Bohr", "Linus Pauling", 1));
                break;

            case "Biology":
                list.add(new Question("What is the basic unit of life?", "Cell", "Atom", "Molecule", "Organ", 1));
                list.add(new Question("Who is known as the Father of Biology?", "Aristotle", "Darwin", "Linnaeus", "Mendel", 1));
                list.add(new Question("Which organelle is known as the powerhouse of the cell?", "Mitochondrion", "Nucleus", "Ribosome", "Golgi Body", 1));
                list.add(new Question("What is the genetic material of most organisms?", "DNA", "RNA", "Protein", "Lipid", 1));
                list.add(new Question("Which process do plants use to convert sunlight into food?", "Photosynthesis", "Respiration", "Transpiration", "Fermentation", 1));
                list.add(new Question("How many chromosomes are in a typical human somatic cell?", "46", "23", "48", "44", 1));
                list.add(new Question("What is the largest organ in the human body?", "Skin", "Liver", "Lungs", "Brain", 1));
                list.add(new Question("Which part of the brain controls balance and coordination?", "Cerebellum", "Cerebrum", "Brainstem", "Thalamus", 1));
                list.add(new Question("What type of blood cells are responsible for fighting infections?", "White blood cells", "Red blood cells", "Platelets", "Plasma", 1));
                list.add(new Question("Who proposed the Theory of Evolution by Natural Selection?", "Charles Darwin", "Gregor Mendel", "Louis Pasteur", "Robert Hooke", 1));
                list.add(new Question("What is the study of fungi called?", "Mycology", "Phycology", "Virology", "Bacteriology", 1));
                list.add(new Question("Which hormone regulates blood sugar levels?", "Insulin", "Adrenaline", "Estrogen", "Thyroxine", 1));
                list.add(new Question("What is the main structural component of plant cell walls?", "Cellulose", "Chitin", "Keratin", "Peptidoglycan", 1));
                list.add(new Question("How many chambers are in a human heart?", "4", "2", "3", "1", 1));
                list.add(new Question("Which process results in two identical daughter cells?", "Mitosis", "Meiosis", "Fertilization", "Budding", 1));
                list.add(new Question("Which gas do animals exhale as a byproduct of respiration?", "Carbon Dioxide", "Oxygen", "Nitrogen", "Methane", 1));
                list.add(new Question("What is the scientific name for modern humans?", "Homo sapiens", "Homo erectus", "Homo habilis", "Neanderthal", 1));
                list.add(new Question("Which vitamin is produced when skin is exposed to sunlight?", "Vitamin D", "Vitamin A", "Vitamin C", "Vitamin K", 1));
                list.add(new Question("What is the primary function of ribosomes?", "Protein synthesis", "Energy production", "Waste removal", "DNA storage", 1));
                list.add(new Question("Which organ in the human body produces bile?", "Liver", "Pancreas", "Gallbladder", "Stomach", 1));
                list.add(new Question("What is the study of heredity called?", "Genetics", "Ecology", "Taxonomy", "Anatomy", 1));
                list.add(new Question("Which part of a flower produces pollen?", "Anther", "Stigma", "Ovary", "Petal", 1));
                list.add(new Question("What is the primary pigment involved in photosynthesis?", "Chlorophyll", "Carotenoid", "Anthocyanin", "Xanthophyll", 1));
                list.add(new Question("Which system transports oxygen and nutrients throughout the body?", "Circulatory System", "Digestive System", "Nervous System", "Respiratory System", 1));
                list.add(new Question("What is the smallest bone in the human body?", "Stapes", "Malleus", "Incus", "Patella", 1));
                list.add(new Question("An organism that lives on another and benefits at its expense is a:", "Parasite", "Symbiont", "Prey", "Producer", 1));
                list.add(new Question("Which organelle packages and ships proteins?", "Golgi Apparatus", "Endoplasmic Reticulum", "Lysosome", "Vacuole", 1));
                list.add(new Question("What is the outer layer of an animal cell called?", "Cell Membrane", "Cell Wall", "Cytoplasm", "Nuclear Envelope", 1));
                list.add(new Question("What is the largest bone in the human body?", "Femur", "Tibia", "Humerus", "Pelvis", 1));
                list.add(new Question("Which specialized cells carry oxygen in the blood?", "Red blood cells", "White blood cells", "Neurons", "Lymphocytes", 1));
                break;

            case "Earth Science":
                list.add(new Question("What is the outermost layer of the Earth?", "Crust", "Mantle", "Outer Core", "Inner Core", 1));
                list.add(new Question("Which type of rock is formed from cooled magma or lava?", "Igneous", "Sedimentary", "Metamorphic", "Fossil", 1));
                list.add(new Question("What is the most abundant gas in the Earth's atmosphere?", "Nitrogen", "Oxygen", "Argon", "Carbon Dioxide", 1));
                list.add(new Question("Which scale is used to measure the magnitude of earthquakes?", "Richter Scale", "Beaufort Scale", "Celsius Scale", "Kelvin Scale", 1));
                list.add(new Question("What is the process of water turning into vapor from plants called?", "Transpiration", "Evaporation", "Condensation", "Precipitation", 1));
                list.add(new Question("What is the name of the supercontinent that existed millions of years ago?", "Pangaea", "Gondwana", "Laurasia", "Atlantis", 1));
                list.add(new Question("Which planet is known as the 'Red Planet'?", "Mars", "Venus", "Jupiter", "Saturn", 1));
                list.add(new Question("What is the primary cause of ocean tides?", "Moon's Gravity", "Sun's Heat", "Earth's Rotation", "Wind", 1));
                list.add(new Question("What layer of the atmosphere contains the ozone layer?", "Stratosphere", "Troposphere", "Mesosphere", "Thermosphere", 1));
                list.add(new Question("What is the study of weather called?", "Meteorology", "Geology", "Astronomy", "Oceanography", 1));
                list.add(new Question("Which type of cloud is often associated with thunderstorms?", "Cumulonimbus", "Cirrus", "Stratus", "Cumulus", 1));
                list.add(new Question("What is the hardest known natural mineral?", "Diamond", "Corundum", "Topaz", "Quartz", 1));
                list.add(new Question("Which Earth layer is liquid?", "Outer Core", "Inner Core", "Mantle", "Crust", 1));
                list.add(new Question("What is the name of the process by which rocks are broken down by physical or chemical means?", "Weathering", "Erosion", "Deposition", "Lithification", 1));
                list.add(new Question("What is the boundary where two tectonic plates move away from each other?", "Divergent Boundary", "Convergent Boundary", "Transform Boundary", "Subduction Zone", 1));
                list.add(new Question("What is the approximate age of the Earth?", "4.5 Billion Years", "4.5 Million Years", "2024 Years", "10 Billion Years", 1));
                list.add(new Question("Which ocean is the largest?", "Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean", 1));
                list.add(new Question("What is the point on the Earth's surface directly above an earthquake's focus?", "Epicenter", "Hypocenter", "Fault line", "Magnitude", 1));
                list.add(new Question("What are huge waves caused by underwater earthquakes called?", "Tsunami", "Tidal Waves", "Swell", "Current", 1));
                list.add(new Question("Which instrument is used to measure wind speed?", "Anemometer", "Barometer", "Hygrometer", "Thermometer", 1));
                list.add(new Question("What is the main component of stars?", "Hydrogen and Helium", "Oxygen and Carbon", "Iron and Nickel", "Rock and Ice", 1));
                list.add(new Question("What is the name for the cycle of water moving between Earth and the atmosphere?", "Hydrological Cycle", "Rock Cycle", "Carbon Cycle", "Nitrogen Cycle", 1));
                list.add(new Question("Which gas contributes most to the greenhouse effect?", "Water Vapor", "Oxygen", "Nitrogen", "Argon", 1));
                list.add(new Question("What is the study of fossils called?", "Paleontology", "Archaeology", "Anthropology", "Biology", 1));
                list.add(new Question("Which planet is the largest in our solar system?", "Jupiter", "Saturn", "Neptune", "Earth", 1));
                list.add(new Question("What is the molten rock found beneath the Earth's surface called?", "Magma", "Lava", "Basalt", "Granite", 1));
                list.add(new Question("What is the process of soil and rock being moved from one place to another?", "Erosion", "Weathering", "Deposition", "Compaction", 1));
                list.add(new Question("Which layer of the Earth is the thickest?", "Mantle", "Crust", "Core", "Atmosphere", 1));
                list.add(new Question("What is the percentage of Earth's surface covered by water?", "Approximately 71%", "Approximately 50%", "Approximately 90%", "Approximately 30%", 1));
                list.add(new Question("What is the name of the galaxy we live in?", "Milky Way", "Andromeda", "Sombrero", "Triangulum", 1));
                break;

            case "Space and Astronomy":
                list.add(new Question("What is the largest planet in our solar system?", "Jupiter", "Saturn", "Neptune", "Uranus", 1));
                list.add(new Question("Which planet is known as the Red Planet?", "Mars", "Venus", "Mercury", "Jupiter", 1));
                list.add(new Question("What is the name of our galaxy?", "Milky Way", "Andromeda", "Sombrero", "Triangulum", 1));
                list.add(new Question("What is the hottest planet in our solar system?", "Venus", "Mercury", "Mars", "Jupiter", 1));
                list.add(new Question("Which planet has the most prominent rings?", "Saturn", "Jupiter", "Neptune", "Uranus", 1));
                list.add(new Question("What is the closest star to Earth?", "The Sun", "Proxima Centauri", "Sirius", "Betelgeuse", 1));
                list.add(new Question("How many planets are in our solar system?", "8", "9", "7", "10", 1));
                list.add(new Question("Who was the first human to travel into space?", "Yuri Gagarin", "Neil Armstrong", "Buzz Aldrin", "John Glenn", 1));
                list.add(new Question("Which planet is known as the 'Blue Giant'?", "Neptune", "Uranus", "Jupiter", "Saturn", 1));
                list.add(new Question("What is the name of the Earth's only natural satellite?", "The Moon", "Titan", "Ganymede", "Europa", 1));
                list.add(new Question("What force keeps planets in orbit around the Sun?", "Gravity", "Magnetism", "Friction", "Centrifugal Force", 1));
                list.add(new Question("What is a 'shooting star' actually?", "A Meteor", "A Comet", "An Asteroid", "A Dying Star", 1));
                list.add(new Question("Which planet is closest to the Sun?", "Mercury", "Venus", "Earth", "Mars", 1));
                list.add(new Question("What was the first artificial satellite launched into space?", "Sputnik 1", "Explorer 1", "Vanguard 1", "Telstar", 1));
                list.add(new Question("Which NASA mission first landed humans on the Moon?", "Apollo 11", "Apollo 13", "Gemini 4", "Mercury 7", 1));
                list.add(new Question("What is the boundary around a black hole called?", "Event Horizon", "Singularity", "Photon Sphere", "Ergosphere", 1));
                list.add(new Question("What type of celestial body is Pluto currently classified as?", "Dwarf Planet", "Planet", "Asteroid", "Comet", 1));
                list.add(new Question("What is the study of the universe called?", "Astronomy", "Astrology", "Geology", "Cosmetology", 1));
                list.add(new Question("What is the name of the largest moon of Saturn?", "Titan", "Rhea", "Enceladus", "Dione", 1));
                list.add(new Question("What unit is used to measure distances between stars?", "Light-year", "Astronomical Unit", "Kilometer", "Mile", 1));
                list.add(new Question("Which planet rotates on its side?", "Uranus", "Neptune", "Saturn", "Jupiter", 1));
                list.add(new Question("What is the name of the giant storm on Jupiter?", "Great Red Spot", "Great Dark Spot", "Eye of Sauron", "The Maelstrom", 1));
                list.add(new Question("Where is the main asteroid belt located?", "Between Mars and Jupiter", "Between Earth and Mars", "Between Jupiter and Saturn", "Beyond Neptune", 1));
                list.add(new Question("What is a collection of billions of stars called?", "Galaxy", "Solar System", "Constellation", "Nebula", 1));
                list.add(new Question("Who was the first person to walk on the Moon?", "Neil Armstrong", "Buzz Aldrin", "Yuri Gagarin", "Michael Collins", 1));
                list.add(new Question("Which telescope was launched into space in 1990?", "Hubble Space Telescope", "James Webb Telescope", "Kepler Telescope", "Spitzer Telescope", 1));
                list.add(new Question("What is the term for a powerful stellar explosion?", "Supernova", "Nova", "Nebula", "Black Hole", 1));
                list.add(new Question("Which planet was known for its Great Dark Spot?", "Neptune", "Uranus", "Saturn", "Jupiter", 1));
                list.add(new Question("What is the most abundant element in the universe?", "Hydrogen", "Helium", "Oxygen", "Carbon", 1));
                list.add(new Question("Which theory explains the origin of the universe?", "The Big Bang Theory", "Steady State Theory", "String Theory", "Evolution Theory", 1));
                break;

            case "Fitness & Exercise":
                list.add(new Question("What is the best way to improve cardiovascular health?", "Running", "Sleeping", "Eating", "Reading", 1));
                break;

            case "Sports":
                list.add(new Question("How many players are on a basketball team on court?", "5", "6", "11", "9", 1));
                break;

            case "Health & Wellness Movement & Skills":
                list.add(new Question("What is the recommended amount of water daily?", "8 glasses", "2 glasses", "15 glasses", "5 glasses", 1));
                break;

            case "Nutrition & Lifestyle":
                list.add(new Question("Which vitamin is found in oranges?", "Vitamin C", "Vitamin D", "Vitamin A", "Vitamin K", 1));
                break;

            case "Ancient History":
                list.add(new Question("Who built the pyramids?", "Egyptians", "Romans", "Greeks", "Mayans", 1));
                list.add(new Question("Which ancient civilization is known for starting the Olympics?", "Greeks", "Romans", "Egyptians", "Persians", 1));
                list.add(new Question("Who was the first emperor of Rome?", "Augustus", "Julius Caesar", "Nero", "Caligula", 1));
                list.add(new Question("Which river was the lifeblood of Ancient Egypt?", "Nile", "Tigris", "Euphrates", "Indus", 1));
                list.add(new Question("The Code of Hammurabi originated from which civilization?", "Babylonian", "Sumerian", "Assyrian", "Hittite", 1));
                list.add(new Question("Which structure was built to protect China from northern invasions?", "Great Wall", "Forbidden City", "Summer Palace", "Temple of Heaven", 1));
                list.add(new Question("Who was the Greek god of the sea?", "Poseidon", "Zeus", "Hades", "Apollo", 1));
                list.add(new Question("What was the writing system of Ancient Egypt called?", "Hieroglyphics", "Cuneiform", "Sanskrit", "Latin", 1));
                list.add(new Question("Which ancient city was famous for its Hanging Gardens?", "Babylon", "Nineveh", "Ur", "Thebes", 1));
                list.add(new Question("Who was the famous queen of Ancient Egypt who met Julius Caesar?", "Cleopatra", "Nefertiti", "Hatshepsut", "Isis", 1));
                list.add(new Question("The Parthenon is located in which city?", "Athens", "Rome", "Sparta", "Alexandria", 1));
                list.add(new Question("Which civilization is credited with the concept of zero?", "Ancient India", "Ancient Greece", "Ancient Rome", "Ancient China", 1));
                list.add(new Question("Who was the Roman god of war?", "Mars", "Jupiter", "Neptune", "Mercury", 1));
                list.add(new Question("Which conqueror created one of the largest empires by age 30?", "Alexander the Great", "Genghis Khan", "Julius Caesar", "Cyrus the Great", 1));
                list.add(new Question("What was the main language spoken in Ancient Rome?", "Latin", "Greek", "Hebrew", "Aramaic", 1));
                list.add(new Question("Which civilization built the mountain city of Machu Picchu?", "Incas", "Mayans", "Aztecs", "Olmecs", 1));
                list.add(new Question("Who was the legendary founder and first king of Rome?", "Romulus", "Remus", "Aeneas", "Numa Pompilius", 1));
                list.add(new Question("What was the name of the Greek marketplace and social hub?", "Agora", "Acropolis", "Forum", "Pantheon", 1));
                list.add(new Question("Which ancient civilization used Cuneiform writing?", "Sumerians", "Egyptians", "Phoenicians", "Minoans", 1));
                list.add(new Question("The Colosseum is located in which modern-day country?", "Italy", "Greece", "Egypt", "Turkey", 1));
                list.add(new Question("Who was the Greek goddess of wisdom?", "Athena", "Aphrodite", "Hera", "Artemis", 1));
                list.add(new Question("Which ancient empire was ruled by Cyrus the Great?", "Persian Empire", "Ottoman Empire", "Byzantine Empire", "Mughal Empire", 1));
                list.add(new Question("What was the primary short sword of a Roman legionary?", "Gladius", "Scimitar", "Katana", "Rapier", 1));
                list.add(new Question("Which ancient civilization lived in the Indus Valley?", "Harappans", "Aryans", "Dravidians", "Mongols", 1));
                list.add(new Question("Who was the Egyptian god of the underworld?", "Osiris", "Anubis", "Ra", "Horus", 1));
                list.add(new Question("Which Greek philosopher was the teacher of Alexander the Great?", "Aristotle", "Plato", "Socrates", "Epicurus", 1));
                list.add(new Question("The Punic Wars were fought between Rome and which city?", "Carthage", "Sparta", "Troy", "Jerusalem", 1));
                list.add(new Question("Which Chinese dynasty started the construction of the Great Wall?", "Qin Dynasty", "Han Dynasty", "Tang Dynasty", "Ming Dynasty", 1));
                list.add(new Question("What was the name of the trade route connecting East and West?", "Silk Road", "Amber Road", "Spice Route", "Incense Route", 1));
                list.add(new Question("Which ancient civilization is famous for its 'Terracotta Army'?", "Ancient China", "Ancient Japan", "Ancient India", "Ancient Korea", 1));
                break;

            case "Wars & Conflicts":
                list.add(new Question("When did World War II end?", "1945", "1918", "1939", "1950", 1));
                list.add(new Question("Which war was fought between the North and South regions of the USA?", "American Civil War", "War of 1812", "Revolutionary War", "Mexican-American War", 1));
                list.add(new Question("The assassination of Archduke Franz Ferdinand triggered which war?", "World War I", "World War II", "Crimean War", "Balkan War", 1));
                list.add(new Question("Who was the leader of Nazi Germany during World War II?", "Adolf Hitler", "Benito Mussolini", "Joseph Stalin", "Winston Churchill", 1));
                list.add(new Question("Which treaty officially ended World War I?", "Treaty of Versailles", "Treaty of Paris", "Treaty of Ghent", "Treaty of Tordesillas", 1));
                list.add(new Question("The 'Cold War' was primarily a standoff between the USA and which other power?", "Soviet Union", "China", "Germany", "Japan", 1));
                list.add(new Question("Which conflict is known as the 'Forgotten War'?", "Korean War", "Vietnam War", "Gulf War", "Iraq War", 1));
                list.add(new Question("In which country did the Vietnam War take place?", "Vietnam", "Korea", "Thailand", "Cambodia", 1));
                list.add(new Question("The Battle of Waterloo saw the final defeat of which leader?", "Napoleon Bonaparte", "Duke of Wellington", "Julius Caesar", "Alexander the Great", 1));
                list.add(new Question("Which event brought the USA into World War II?", "Attack on Pearl Harbor", "Invasion of Poland", "Sinking of the Lusitania", "D-Day", 1));
                list.add(new Question("The Magna Carta was signed during the reign of which English King?", "King John", "King Richard", "King Henry VIII", "King George III", 1));
                list.add(new Question("Which revolution led to the execution of King Louis XVI?", "French Revolution", "American Revolution", "Russian Revolution", "Industrial Revolution", 1));
                list.add(new Question("The 'Iron Curtain' speech was delivered by whom?", "Winston Churchill", "Franklin D. Roosevelt", "Harry Truman", "Dwight Eisenhower", 1));
                list.add(new Question("Who were the primary opponents in the Punic Wars?", "Rome and Carthage", "Greeks and Persians", "Spartans and Athenians", "Egyptians and Hittites", 1));
                list.add(new Question("Which war began with the invasion of Poland in 1939?", "World War II", "World War I", "Spanish Civil War", "Winter War", 1));
                list.add(new Question("The Hundred Years' War was fought between which two countries?", "England and France", "Spain and Portugal", "Germany and Austria", "Rome and Greece", 1));
                list.add(new Question("Which military alliance was formed by Western nations in 1949?", "NATO", "Warsaw Pact", "United Nations", "League of Nations", 1));
                list.add(new Question("Who was the main commander of the Allied forces on D-Day?", "Dwight D. Eisenhower", "Douglas MacArthur", "George Patton", "Bernard Montgomery", 1));
                list.add(new Question("The Hiroshima and Nagasaki bombings ended the war with which country?", "Japan", "Germany", "Italy", "Soviet Union", 1));
                list.add(new Question("Which wall was a symbol of the Cold War and fell in 1989?", "Berlin Wall", "Great Wall", "Western Wall", "Hadrian's Wall", 1));
                list.add(new Question("The Battle of Gettysburg was a turning point in which war?", "American Civil War", "Revolutionary War", "War of 1812", "World War I", 1));
                list.add(new Question("Who led the 'Red Shirts' in the unification of Italy?", "Giuseppe Garibaldi", "Otto von Bismarck", "Napoleon III", "Camillo Cavour", 1));
                list.add(new Question("Which empire did the Ottoman Empire replace in 1453?", "Byzantine Empire", "Roman Empire", "Persian Empire", "Mongol Empire", 1));
                list.add(new Question("The Opium Wars were fought between Great Britain and which dynasty?", "Qing Dynasty", "Ming Dynasty", "Han Dynasty", "Yuan Dynasty", 1));
                list.add(new Question("Which US President made the decision to drop the atomic bombs?", "Harry S. Truman", "Franklin D. Roosevelt", "John F. Kennedy", "Lyndon B. Johnson", 1));
                list.add(new Question("The 'Bay of Pigs' invasion was an attempt to overthrow the government of which country?", "Cuba", "Vietnam", "Korea", "Panama", 1));
                list.add(new Question("Which explorer's voyage led to the first circumnavigation of the globe?", "Ferdinand Magellan", "Christopher Columbus", "Vasco da Gama", "James Cook", 1));
                list.add(new Question("The 'Desert Storm' operation took place during which conflict?", "Gulf War", "Iraq War", "Afghanistan War", "Vietnam War", 1));
                list.add(new Question("Which Russian leader led the Bolshevik Revolution in 1917?", "Vladimir Lenin", "Joseph Stalin", "Leon Trotsky", "Nicholas II", 1));
                list.add(new Question("The 'Zimmermann Telegram' helped draw the USA into which war?", "World War I", "World War II", "Spanish-American War", "Mexican-American War", 1));
                break;

            case "Leaders & Important People":
                list.add(new Question("Who was the first president of the USA?", "George Washington", "Abraham Lincoln", "Thomas Jefferson", "John Adams", 1));
                list.add(new Question("Who led India to independence through nonviolent resistance?", "Mahatma Gandhi", "Jawaharlal Nehru", "Subhas Chandra Bose", "Sardar Patel", 1));
                list.add(new Question("Who was the first female Prime Minister of the United Kingdom?", "Margaret Thatcher", "Theresa May", "Angela Merkel", "Indira Gandhi", 1));
                list.add(new Question("Who was the principal author of the Declaration of Independence?", "Thomas Jefferson", "Benjamin Franklin", "John Adams", "James Madison", 1));
                list.add(new Question("Who delivered the 'I Have a Dream' speech?", "Martin Luther King Jr.", "Malcolm X", "Rosa Parks", "Nelson Mandela", 1));
                list.add(new Question("Who was the first black president of South Africa?", "Nelson Mandela", "Desmond Tutu", "Thabo Mbeki", "Robert Mugabe", 1));
                list.add(new Question("Who was the first woman to win a Nobel Prize?", "Marie Curie", "Mother Teresa", "Jane Addams", "Florence Nightingale", 1));
                list.add(new Question("Who was the longest-reigning British monarch before Queen Elizabeth II?", "Queen Victoria", "Queen Elizabeth I", "King George III", "King Henry VIII", 1));
                list.add(new Question("Who was the leader of the Soviet Union during World War II?", "Joseph Stalin", "Vladimir Lenin", "Nikita Khrushchev", "Leon Trotsky", 1));
                list.add(new Question("Who was the first woman to fly solo across the Atlantic?", "Amelia Earhart", "Bessie Coleman", "Harriet Quimby", "Amy Johnson", 1));
                list.add(new Question("Who was the Roman dictator assassinated on the Ides of March?", "Julius Caesar", "Augustus", "Nero", "Caligula", 1));
                list.add(new Question("Who led the Free French Forces during WWII?", "Charles de Gaulle", "Philippe Pétain", "Jean Moulin", "Napoleon III", 1));
                list.add(new Question("Who was the first head of the Soviet state?", "Vladimir Lenin", "Joseph Stalin", "Mikhail Gorbachev", "Leon Trotsky", 1));
                list.add(new Question("Who was the first female Prime Minister of Israel?", "Golda Meir", "Indira Gandhi", "Margaret Thatcher", "Benazir Bhutto", 1));
                list.add(new Question("Who founded the People's Republic of China?", "Mao Zedong", "Deng Xiaoping", "Sun Yat-sen", "Chiang Kai-shek", 1));
                list.add(new Question("Who was the US President during the American Civil War?", "Abraham Lincoln", "Andrew Jackson", "Ulysses S. Grant", "Jefferson Davis", 1));
                list.add(new Question("Who was the long-time revolutionary leader of Cuba?", "Fidel Castro", "Che Guevara", "Hugo Chavez", "Fulgencio Batista", 1));
                list.add(new Question("Who was the first female Prime Minister of India?", "Indira Gandhi", "Sonia Gandhi", "Pratibha Patil", "Sarojini Naidu", 1));
                list.add(new Question("Who was the French Emperor who conquered much of Europe?", "Napoleon Bonaparte", "Louis XIV", "Charlemagne", "Louis XVI", 1));
                list.add(new Question("Who started the Protestant Reformation?", "Martin Luther", "John Calvin", "Henry VIII", "Erasmus", 1));
                list.add(new Question("Who was known as 'The Lady with the Lamp'?", "Florence Nightingale", "Clara Barton", "Mother Teresa", "Mary Seacole", 1));
                list.add(new Question("Who wrote a famous diary while in hiding during the Holocaust?", "Anne Frank", "Elie Wiesel", "Oskar Schindler", "Rosa Parks", 1));
                list.add(new Question("Who is known as 'The Liberator' of South America?", "Simon Bolivar", "Jose de San Martin", "Bernardo O'Higgins", "Che Guevara", 1));
                list.add(new Question("Who was the first person to walk on the moon?", "Neil Armstrong", "Buzz Aldrin", "Yuri Gagarin", "John Glenn", 1));
                list.add(new Question("Who was the UK Prime Minister during most of WWII?", "Winston Churchill", "Neville Chamberlain", "Clement Attlee", "Anthony Eden", 1));
                list.add(new Question("Who was the last active ruler of the Ptolemaic Kingdom of Egypt?", "Cleopatra", "Nefertiti", "Hatshepsut", "Arsinoe IV", 1));
                list.add(new Question("Who is the 14th Dalai Lama?", "Tenzin Gyatso", "Lobsang Gyatso", "Dalai Lama XIII", "Panchen Lama", 1));
                list.add(new Question("Who was the first Catholic President of the United States?", "John F. Kennedy", "Joe Biden", "Al Smith", "Franklin D. Roosevelt", 1));
                list.add(new Question("Who was the first female US Secretary of State?", "Madeleine Albright", "Condoleezza Rice", "Hillary Clinton", "Susan Rice", 1));
                list.add(new Question("Who founded the Mongol Empire?", "Genghis Khan", "Kublai Khan", "Tamerlane", "Batu Khan", 1));
                break;

            case "Asian & Philippine History":
                list.add(new Question("Who is the national hero of the Philippines?", "Jose Rizal", "Andres Bonifacio", "Emilio Aguinaldo", "Apolinario Mabini", 1));
                break;

            case "Visual Arts":
                list.add(new Question("Who painted the Mona Lisa?", "Leonardo da Vinci", "Vincent van Gogh", "Pablo Picasso", "Claude Monet", 1));
                break;

            case "Performing Arts":
                list.add(new Question("What is the primary tool of an actor?", "Voice and Body", "Script", "Costume", "Stage", 1));
                break;

            case "Music":
                list.add(new Question("How many notes are in a major scale?", "7", "5", "8", "12", 1));
                break;

            case "Architecture":
                list.add(new Question("What is the tallest building in the world?", "Burj Khalifa", "Empire State Building", "Eiffel Tower", "Taipei 101", 1));
                break;

            case "Cultural & Contemporary Arts":
                list.add(new Question("What is street art often called?", "Graffiti", "Impressionism", "Sculpture", "Realism", 1));
                break;
        }

        return list;
    }
}
