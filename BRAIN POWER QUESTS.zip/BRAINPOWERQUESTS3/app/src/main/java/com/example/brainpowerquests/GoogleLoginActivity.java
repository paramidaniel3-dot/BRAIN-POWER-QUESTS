package com.example.brainpowerquests;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GoogleLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_login);

        EditText emailInput = findViewById(R.id.emailInput);
        EditText passwordInput = findViewById(R.id.passwordInput);
        Button loginBtn = findViewById(R.id.loginBtn);
        Button backBtn = findViewById(R.id.backBtn);

        loginBtn.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Save login credentials to SharedPreferences
                SharedPreferences sharedPref = getSharedPreferences("UserAuth", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("email", email);
                editor.putString("password", password);
                editor.putBoolean("isLoggedIn", true);
                editor.apply();

                // After successful login, go to Profile Information
                Intent intent = new Intent(GoogleLoginActivity.this, ProfileActivity.class);
                startActivity(intent);
                finish();
            }
        });

        if (backBtn != null) {
            backBtn.setOnClickListener(v -> {
                finish();
            });
        }
    }
}
